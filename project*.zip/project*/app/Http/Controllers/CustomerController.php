<?php
/**
 * Created by linzhonghuang.
 * User: linzh
 * Date: 2016/11/15
 * Time: 15:43
 */

namespace App\Http\Controllers;


class CustomerController extends Controller
{


    public function lists(){

    }


}