<?php

class Wang{
	public static function ceshi(){
		echo 'ceshi';
	}
	public static function json($arr){
		echo json_encode($arr);
	}
}