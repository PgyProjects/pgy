<?php

/**
 * 系统自动生成
 * @author auto create
 */
class Result
{
	
	/** 
	 * code
	 **/
	public $code;
	
	/** 
	 * model
	 **/
	public $models;
	
	/** 
	 * 系统自动生成
	 **/
	public $msg;
	
	/** 
	 * true返回成功，false返回失败
	 **/
	public $success;	
}
?>