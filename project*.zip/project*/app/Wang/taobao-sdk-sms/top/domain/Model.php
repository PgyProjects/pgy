<?php

/**
 * model
 * @author auto create
 */
class Model
{
	
	/** 
	 * flowResource
	 **/
	public $flow_resource;
	
	/** 
	 * resourceType
	 **/
	public $resource_type;
	
	/** 
	 * restOfFlow
	 **/
	public $rest_of_flow;	
}
?>